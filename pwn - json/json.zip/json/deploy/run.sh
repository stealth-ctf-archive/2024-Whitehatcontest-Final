#!/bin/bash

su -c '/home/ctf/prob' ctf