<?php
require_once("../common.php");
require_once("../util/filefunc.php");
require_once('sql.php');
?>