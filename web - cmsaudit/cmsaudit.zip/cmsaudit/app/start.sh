#!/bin/bash

# MariaDB 서비스 시작

service mariadb start
# Apache 시작

# su losevanni  -s /bin/sh -c "apache2-foreground"
apache2-foreground