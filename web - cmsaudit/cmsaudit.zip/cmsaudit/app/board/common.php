<?php
require_once("../common.php");
require_once('sql.php');
?>